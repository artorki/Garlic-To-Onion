import socket
from time import sleep
from colorama import Fore
import requests
from Banner import banner


ly,lr,lg,w = Fore.LIGHTYELLOW_EX,Fore.LIGHTRED_EX,Fore.LIGHTGREEN_EX,Fore.WHITE


def whois():
    banner()

    sleep(0.05)
    print(ly,"–•[WHOIS]•–———————————————————————————————————————————————————————————")

    sleep(0.05)
    print(ly,"\n [!] ENTER A URL:")

    sleep(0.05)
    print(w)
    url = input(" @G.O>>> ")

    if url == "0" :
        exit()
    elif url == "" :
        print(lr,"\n ERROR")
        exit()
 
    server =  "https://whois.com/whois/" + str(url) + "/json/"

    try:
        r = requests.get(server)
        print(lg,"\n " + r.json)

    except:
        print(lr,"\n ERROR")

    print(ly,"\n Finish")

whois()